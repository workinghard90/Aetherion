# Contributing to AetherionAI

Welcome, Guardian. Here's how to contribute sacredly.

---

## Setup

1. **Clone the repo**
   ```bash
   git clone https://github.com/YOUR_ORG/AetherionAI.git
   cd AetherionAI
   ```

2. **Install dependencies**
   ```bash
   ./setup.sh
   ```

3. **Run services**
   ```bash
   yarn start:backend
   yarn start:expo
   ```

---

## Guidelines

- **Branch**: use `feature/your-feature` or `fix/your-bug`
- **Commits**: use [Conventional Commits](https://www.conventionalcommits.org/)
- **Style**:
  - Python: PEP8, use `black`
  - JS/TS: use `eslint`, `prettier`

---

## Pull Requests

- Target: `main`
- Required:
  - Descriptive title
  - PR template checklist
  - Green CI
- Optional:
  - Screenshots for UI changes
  - Explain decisions made

---

## Test Your Work

- Backend: curl or Postman for `/api/status`
- Frontend: Expo DevTools in browser or device

---

Thank you for helping grow The Grove.
