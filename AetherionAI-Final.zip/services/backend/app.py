from flask import Flask
from flask_cors import CORS
from routes.docs import docs
from routes.gates import gates
from routes.veil import veil

app = Flask(__name__)
CORS(app)
app.register_blueprint(docs)
app.register_blueprint(gates)
app.register_blueprint(veil)

if __name__ == "__main__":
    app.run(debug=True, port=10000)
