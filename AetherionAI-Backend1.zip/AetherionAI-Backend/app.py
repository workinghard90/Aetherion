from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import json
from datetime import datetime
import os

app = Flask(__name__)
CORS(app)
DATABASE = 'universe.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS universe (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            type TEXT,
            description TEXT,
            properties TEXT,
            created_at TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/api/items', methods=['GET'])
def get_universe():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM universe')
    rows = cursor.fetchall()
    conn.close()
    universe = [{
        'id': row[0],
        'name': row[1],
        'type': row[2],
        'description': row[3],
        'properties': json.loads(row[4]),
        'created_at': row[5]
    } for row in rows]
    return jsonify(universe)

@app.route('/api/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM universe WHERE id=?', (item_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return jsonify({
            'id': row[0],
            'name': row[1],
            'type': row[2],
            'description': row[3],
            'properties': json.loads(row[4]),
            'created_at': row[5]
        })
    return jsonify({'error': 'Item not found'}), 404

@app.route('/api/items', methods=['POST'])
def create_entity():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO universe (name, type, description, properties, created_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        data['name'],
        data['type'],
        data.get('description', ''),
        json.dumps(data.get('properties', {})),
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()
    return jsonify({'status': 'created'})

@app.route('/api/items/<int:item_id>', methods=['PUT'])
def update_entity(item_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE universe
        SET name=?, type=?, description=?, properties=?
        WHERE id=?
    ''', (
        data['name'],
        data['type'],
        data.get('description', ''),
        json.dumps(data.get('properties', {})),
        item_id
    ))
    conn.commit()
    conn.close()
    return jsonify({'status': 'updated'})

@app.route('/api/items/<int:item_id>', methods=['DELETE'])
def delete_entity(item_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM universe WHERE id=?', (item_id,))
    conn.commit()
    conn.close()
    return jsonify({'status': 'deleted'})

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 10000))
    app.run(host='0.0.0.0', port=port)
